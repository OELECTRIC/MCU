/*
 * Attiny13.c
 *
 * Created: 12/4/2563 17:47:29
 * Author : Romeo
 */ 

#include <avr/io.h>
#define F_CPU 96E5
#include <util/delay.h>

int main(void)
{
	DDRB = 0xFF;
    /* Replace with your application code */
    while (1) 
    {
		PORTB = 0x00;
		_delay_ms(500);
		PORTB = 0xFF;
		_delay_ms(500);
    }
}

